# V4 authoring update — 2026-10-27

This is a work-in-progress supplement to the Db2 LUW DBA V3 release in this repository. It does not replace the existing V3 HTML lesson or imply that the V4 course is release-ready.

## Progress

- 31 of 68 V4 lesson drafts are present: A-01 through C-07, D-01 through D-06, E-01 through E-06, and F-01.
- All 31 remain partial against the V4 microtopic audit; the course is not a complete release.
- F-01 is the latest authored lesson. F-02, Recovery Objectives and Backup Design, is the next topic.
- IBM Db2 12.1 references were checked for F-01. Commands were not executed against a Db2 server.

## Latest lesson

[ F-01 — Db2 logging and recoverability (V4 draft) ](F-01-logging-recoverability-v4-draft.md)

The complete V4 working source, coverage ledger, and gap audit remain in the course workspace. This supplement preserves the V3 release files as they were.
