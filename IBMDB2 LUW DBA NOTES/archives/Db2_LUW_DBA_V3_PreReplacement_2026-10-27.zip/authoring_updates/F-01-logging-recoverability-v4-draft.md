# F-01 — Db2 logging and recoverability

**Level:** Core operations · **Risk:** transaction availability, disk exhaustion, and recoverability · **Baseline:** Db2 LUW 12.1, single-partition Linux lab · **Scope:** disposable `DBA_LAB` only

## Outcome and decision

Choose a logging configuration that supports the required recovery point, and prove that Db2 can retain and retrieve the logs needed to reach it. Logging mode is a database-level decision with instance/member and host storage consequences. Circular logging supports crash recovery and offline image recovery to the backup point. Archive logging makes the database rollforward recoverable; it does not by itself provide a usable backup or prove that archived logs are retained and retrievable.

```mermaid
flowchart LR
  TX[Transaction records] --> BUF[Log buffer]
  BUF --> ACTIVE[Active log path<br/>crash recovery and in-flight work]
  ACTIVE -->|circular: reuse when safe| ACTIVE
  ACTIVE -->|archive method configured| ARCH[Archive destination]
  IMAGE[Backup image] --> RESTORE[Restore]
  ARCH --> RF[Rollforward to selected endpoint]
  ACTIVE -. missing space or held log .-> FULL[SQL0964C / write pressure]
  ARCH -. unavailable or full .-> HOLD[Archive backlog / log headroom loss]
  RESTORE --> RF
```

The diagram is a conceptual flow: exact log placement, naming, and recovery behavior vary by archive method and topology. In HADR and pureScale, use their supported log-stream and configuration rules; do not extrapolate single-partition paths.

## Modes and their consequences

| Configuration | Recovery consequence | Operational obligation |
|---|---|---|
| `LOGARCHMETH1=OFF` and `LOGARCHMETH2=OFF` | Circular logging; crash recovery and offline backup version recovery. No rollforward through later transactions. | Protect the offline backup and accept the recovery point at that image. |
| At least one archive method enabled | Archive logging; rollforward recovery is available after the required backup and log chain exist. | Monitor archive success, protect every required log, and rehearse retrieval and restore. |
| `LOGRETAIN` | Db2 retains logs for user-managed archival/retrieval. | A separate process must archive and safely remove/retrieve eligible logs; never delete logs by age alone. |
| `LOGSECOND=-1` | Infinite active log space via archive retrieval; not supported for HADR or pureScale. | Requires archive logging, storage controls, and awareness that rollback/crash recovery can become slow. It does not mean infinite disk capacity. |

The logging mode is only one part of recoverability. A recoverable database needs a valid backup baseline, a continuous usable log chain, sufficient storage, and a tested restore/rollforward procedure. Online backup requires archive logging. Switching from circular to archive logging has a backup/reactivation boundary; do not treat the parameter update as proof of recoverability.

## Inspect before changing anything

Run from the Db2 CLP as an authorized instance environment on the database host. Capture the database alias, host, instance, Db2 level, timestamp, and whether the database is active. `GET DB CFG` is read-only.

```text
db2level
db2 get db cfg for DBA_LAB show detail
db2pd -db DBA_LAB -logs
db2 list applications show detail
```

Interpret the configuration values for `LOGARCHMETH1`, `LOGARCHMETH2`, `LOGPRIMARY`, `LOGSECOND`, `LOGFILSIZ`, `LOGBUFSZ`, `NEWLOGPATH`, `MIRRORLOGPATH`, `OVERFLOWLOGPATH`, and `BLK_LOG_DSK_FUL`. `db2pd -logs` is a point-in-time view of log usage and paths, not a substitute for archive-destination monitoring. Check the filesystem containing the active and archive paths on every relevant host/member, and compare space with the actual configured allocation and peak workload. For a finite configuration, a planning estimate for active log space is:

`(LOGPRIMARY + LOGSECOND) × (LOGFILSIZ + 2) × 4096 bytes`

This is a planning estimate, not a complete disk budget; archive backlog, mirrors, headers, formatting, filesystem reserve, and other databases also consume space. `LOGSECOND=-1` cannot be inserted into this formula.

## Configure archive logging: guarded change outline

This example is an outline for a planned lab change only. Before execution, choose and create an empty, Db2-writable archive destination with capacity and monitoring; ensure it is not shared with another database's log archive files. Record current configuration and an approved rollback plan. Changing the logging mode can affect activation and requires a new offline backup before the database can be reactivated for use.

```text
db2 update db cfg for DBA_LAB using logarchmeth1 DISK:/db2archive/DBA_LAB
db2 get db cfg for DBA_LAB
```

Do not assume the command output means the change is active or that archive writes succeed. Follow the documented activation boundary for the exact configuration, prevent application use until the required offline backup is completed, then verify the effective configuration, successful backup, archive output, and available log/filesystem headroom. Avoid hand-editing archive directories or deleting archived logs as a cleanup shortcut.

### Log sizing and buffer decisions

- `LOGPRIMARY` and `LOGFILSIZ` establish the baseline active-log allocation; `LOGSECOND` permits additional logs as required, up to its configured bound. Size from observed peak concurrent work and largest units of work, not average daily log volume.
- `LOGFILSIZ` changes have startup implications. Plan a controlled restart/activation window where applicable; do not expect a value update alone to resize in-use files immediately.
- `LOGBUFSZ` controls the log buffer, measured in pages. Consider changing it only when wait and workload evidence supports it; it does not fix exhausted active-log capacity or a broken archive destination.
- `MAX_LOG` and `NUM_LOG_SPAN` affect workload log limits/behavior. Evaluate application transaction boundaries and the parameter-specific support/activation class before changing them.
- Budget each database and member/partition separately. In DPF, investigate the notification evidence across all members. In pureScale, honor the global/member scope table in the exact release documentation.

## Failure branches and evidence

| Symptom | Evidence and likely branch | Safe response and verification |
|---|---|---|
| `SQL0964C` and `ADM1823E` identifies an application handle | The unit of work may be holding required active logs; rollback can take time. Inspect notification log, `db2diag.log`, application handle, transaction age, and log utilization. | Coordinate with the application owner to commit/rollback or terminate only under the incident procedure. Allow rollback to finish. Recheck the handle, active-log headroom, and successful writes. Increasing `LOGSECOND` may be a controlled temporary bridge if disk capacity and support permit; restore the previous value after the incident. |
| `SQL0964C` without a useful handle or log use does not fall | Check for indoubt transactions, archive failures, pinned logs, and topology-specific member evidence. | Resolve the actual indoubt/archive/pinned-log cause. Do not force-stop Db2 or delete log files to “free space.” Escalate if the transaction outcome or log chain is uncertain. |
| Archive destination errors or archive backlog grows | Check `db2diag.log`/notification log for archive method errors, destination mount/access, free bytes/inodes, permissions, retry settings, and archive-service health. | Restore destination availability/capacity or the archive service using its runbook. Verify a fresh archive operation succeeds and backlog/headroom recover. Preserve needed logs. |
| Active log filesystem fills while database writes are blocked | Correlate `db2pd -logs`, filesystem capacity, oldest active/pinned log, long transactions, and database/member identity. | Free only unrelated files under filesystem ownership procedures, add approved capacity, or resolve the transaction holding logs. Never manually remove active Db2 logs. Confirm filesystem headroom and log reuse after the cause clears. |
| Database is not rollforward recoverable after a mode change | Check effective database configuration, activation state, and backup history. Archive logging alone is not the required baseline image. | Follow the documented offline backup/reactivation sequence. Do not claim point-in-time recovery until an appropriate backup and continuous logs have been validated. |

`FORCE APPLICATION` can cause application failure and lengthy rollback; it is an incident action, not routine log cleanup. `LOGSECOND=-1` can extend recovery time and is unavailable for HADR/pureScale; it must not replace archive monitoring or capacity planning.

## Practice lab (planning only)

On paper or in an isolated, disposable Db2 12.1 instance, record current `DBA_LAB` logging configuration and `db2pd -logs` evidence. Calculate the finite active-log estimate, identify the active and archive filesystems, and compare the available capacity with a stated peak transaction scenario. Choose circular or archive logging from a made-up recovery objective. If archive logging is selected, draw the required image and log chain and write a precheck, activation/backup gate, success evidence, failure stop condition, and rollback/escalation owner. Do not make a configuration change on a shared or production database as part of this exercise.

**Answer check:** archive logging is necessary for rollforward, but insufficient without the correct backup and retrievable uninterrupted logs. A full archive target can eventually remove active-log headroom and cause application writes to fail. Infinite logging is not a universal fix and is unsupported in HADR and pureScale. A good plan proves both space and retrieval, then validates by restore rehearsal.

## References (Db2 12.1)

- IBM, [Configuring database logging options](https://www.ibm.com/docs/en/db2/12.1.x?topic=availability-configuring-database-logging)
- IBM, [Circular logging](https://www.ibm.com/docs/en/db2/12.1.x?topic=logging-circular)
- IBM, [Log file allocation and removal](https://www.ibm.com/docs/en/db2/12.1.x?topic=management-log-file-allocation-removal)
- IBM, [LOGARCHMETH1 configuration parameter](https://www.ibm.com/docs/en/db2/12.1.x?topic=parameters-logarchmeth1-primary-log-archive-method)
- IBM, [LOGSECOND configuration parameter](https://www.ibm.com/docs/en/db2/12.1.x?topic=parameters-logsecond-number-secondary-log-files)
- IBM, [Space requirements for log files](https://www.ibm.com/docs/en/db2/12.1.x?topic=databases-space-requirements-log-files)
- IBM, [Troubleshooting SQL0964C full transaction log](https://www.ibm.com/docs/en/db2/12.1.x?topic=servers-troubleshooting-full-transaction-log-error)

**Validation status:** references checked against IBM Db2 12.1 documentation on 2026-10-27. Commands and procedure were not executed against a Db2 server in this workspace.
